# Howto deb
https://www.internalpointers.com/post/build-binary-deb-package-practical-guide
